package com.thinroot.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.thinroot.demo.model.EmployeeDetails;
import com.thinroot.demo.model.EmployeeProject;
import com.thinroot.demo.service.EmployeeDetailsService;
import com.thinroot.demo.service.EmployeeProjectService;
import com.thinroot.demo.validator.BadRequestException;

@Controller
public class EmployeeProjectController {
	
	@Autowired
	private EmployeeProjectService projectService;
	
	@Autowired 
	private EmployeeDetailsService employeeService;
	//add project details
	@PostMapping("/AddProject")
	public @ResponseBody ResponseEntity<?> addProject(@RequestBody EmployeeProject project, @RequestParam String empId) {
		Optional<EmployeeDetails> details=employeeService.findByempid(empId);
		try {
			if(details.isPresent()) {
			projectService.create(project);
			return new ResponseEntity<>("success",HttpStatus.OK);
			}
			else {
			return new ResponseEntity<>("Employee does not created",HttpStatus.BAD_REQUEST);
			}
			}
		catch(BadRequestException e) {
		 return new ResponseEntity<>("you are trying to add null value",HttpStatus.BAD_REQUEST);
		}
	}
	//adding project details
	/*
	 * @PostMapping("/project") public @ResponseBody ResponseEntity<?>
	 * createProject(@RequestBody EmployeeProject project ) {
	 * projectService.create(project); return new
	 * ResponseEntity<>("success",HttpStatus.OK); }
	 */
	
	//get the single project details
	
	@GetMapping("/getProjectById")
	public EmployeeProject getSingleProject(@RequestParam int projectid) {
		System.out.println("getting record!!!!");
		return projectService.findById(projectid)
				.orElseThrow(()-> new UsernameNotFoundException("project Does not exist with the id   "+projectid));
		}
	
	// update the project details
	@PutMapping("/updatePro")
	public @ResponseBody ResponseEntity<?> updateEmployee(@RequestBody EmployeeProject project,@RequestParam(required=true) String empId,@RequestParam(required=true) int projectid) {
		projectService.update(project,empId,projectid);
		return new ResponseEntity<>("updated successfully",HttpStatus.OK);
		
	}
		

	// delete the project by project id
	@ResponseBody
	@DeleteMapping("/deleteProject")
	public ResponseEntity<?> deleteProject(@RequestParam int projectid) {
		Optional<EmployeeProject> project=projectService.findById(projectid);
		if(project.isPresent()) {
		projectService.proDeleteById(projectid);
		return new ResponseEntity<>("deleted successfully",HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>("project "+projectid+" not found",HttpStatus.NOT_FOUND);
			}
		}
	
	// delete the project by Employee id
	@Transactional
	@ResponseBody
	@DeleteMapping("/deleteProjectUsingEmpId")
	public ResponseEntity<?> deleteProjectByEmpId(@RequestParam String empId) {
		List<EmployeeProject> project=projectService.findByempIdAll(empId);
		if(project.isEmpty()) {
			return new ResponseEntity<>("no projects found for "+empId,HttpStatus.NOT_FOUND);		
			}
		else { 
		projectService.deleteByempId(empId);
		return new ResponseEntity<>("succesfully deletd ",HttpStatus.OK);		
		}
	}
	
	// to get multiple projects of single employee  
	
	@GetMapping("/getMutilPro")
	public List<EmployeeProject> getMutipleProjects(@RequestParam String empId)  {
		System.out.println("getting record!!!!");
		
		return projectService.findByempIdAll(empId);
		}
	
	// to delete all the projects 
	@ResponseBody
	@DeleteMapping("DeleteAllProjects")
	public String deleteAll() {
		projectService.deleteAllProject();
		return "All projects Deleted succesfully";
		}
}
	

