package com.thinroot.demo.controller;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.thinroot.demo.model.EducationalDetails;
import com.thinroot.demo.model.EmployeeDetails;
import com.thinroot.demo.service.EducationalDetailsService;
import com.thinroot.demo.service.EmployeeDetailsService;
import com.thinroot.demo.validator.BadRequestException;

@RestController
public class EducationalDetailsController
{
	@Autowired
	private EducationalDetailsService educationalService;
	@Autowired 
	private EmployeeDetailsService employeeService;
	
	//adding education details
	@PostMapping("/addEducation")
	public @ResponseBody ResponseEntity<?>  save(@RequestBody EducationalDetails eduDetails) {
		EmployeeDetails details=employeeService.findByempid(eduDetails.getEmpId()).orElseThrow(() -> new UsernameNotFoundException("employee does not exist"));
		try {
			educationalService.create(eduDetails);
			return new ResponseEntity<>("successfully added",HttpStatus.ACCEPTED);
		}
		catch(BadRequestException e) {
			 return new ResponseEntity<>("you are trying to add null value",HttpStatus.BAD_REQUEST);
			}
	}
 
	// end point for to fetch the education details of the particular employee 
	
	@ResponseBody
	@GetMapping("/getEducation")
	public  List<EducationalDetails> getEducation(@RequestParam String empId) {	
		if(educationalService.findByempId(empId)==null) {
			throw new UsernameNotFoundException("education details were not found with the employee "+empId);
		}
		return educationalService.findByempId(empId);

		}
		
		
	// end point for update education details
	@PutMapping("/updateEducation")
	public @ResponseBody ResponseEntity<?> updateEdu(@RequestBody EducationalDetails educationalDetails,@RequestParam(required=true) String empId,@RequestParam(required=true) int edid) {		
			educationalService.update(educationalDetails,empId,edid);
			return new ResponseEntity<>("updated successfully",HttpStatus.ACCEPTED);		
		}
	
	@DeleteMapping("/deleteEducationUsingId")
	public ResponseEntity<?> delete(@RequestParam int edid) {
		educationalService.deleteById(edid);
		return new ResponseEntity<>("deleted successsfully",HttpStatus.OK);
	}
	// end point for delete education details
	@Transactional
	@DeleteMapping("deleteEducation")
	public ResponseEntity<?> deleteEdu(@RequestParam String empId) {
			educationalService.deleteByempId(empId);
			return new ResponseEntity<>("deleted successsfully",HttpStatus.OK);
		}
	//delete all education 
	@DeleteMapping("/DeleteAllEducationDetails")
	public String deleteAllEducation()
	{
		educationalService.delete();
		return "deleted successFully";
		
	}

}
