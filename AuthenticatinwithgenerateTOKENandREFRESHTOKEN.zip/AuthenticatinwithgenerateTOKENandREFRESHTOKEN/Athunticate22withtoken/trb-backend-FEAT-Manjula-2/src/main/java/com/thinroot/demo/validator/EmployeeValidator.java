package com.thinroot.demo.validator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.thinroot.demo.model.EmployeeDetails;

@Component
public class EmployeeValidator {

	
	public List<Error> validateCreateEmployeeRequest(EmployeeDetails emp) {

		
        List<Error> errors = new ArrayList<>();

        // id
        if(emp.getEmpId() == null || emp.getEmpId()==""){
            Error error = new Error("Employee Should not be null");
            errors.add(error);
        }

        
        if(emp.getFirstName() == null){
            Error error = new Error("name is null");
            errors.add(error);
        }
        if(emp.getLastName() == null){
            Error error = new Error("Lastname is null");
            errors.add(error);
        }
        if(emp.getAge() == 0){
            Error error = new Error("age is null");
            errors.add(error);
        }
        if(emp.getArea() == null){
            Error error = new Error("area is null");
            errors.add(error);
        }
        if(emp.getCity() == null){
            Error error = new Error("city is null");
            errors.add(error);
        }
        if(emp.getCountry() == null){
            Error error = new Error("country is null");
            errors.add(error);
        }
        if(emp.getLastName() == null){
            Error error = new Error("Lastname is null");
            errors.add(error);
        }
        if(emp.getCurrentAddress() == null){
            Error error = new Error("current Address is null");
            errors.add(error);
        }
        if(emp.getCurrentSalary() == null){
            Error error = new Error(" please mention your current salary");
            errors.add(error);
        }
        if(emp.getExpectedSalary() == null){
            Error error = new Error("expected salary is null");
            errors.add(error);
        }
        if(emp.getGender() == null){
            Error error = new Error("gender is null");
            errors.add(error);
        }
        if(emp.getHomeAddress() == null){
            Error error = new Error("you have missed the home address");
            errors.add(error);
        }
        if(emp.getLanguage() == null){
            Error error = new Error("please mention the language");
            errors.add(error);
        }
        if(emp.getMailId() == null){
            Error error = new Error("mailId is null");
            errors.add(error);
        }
        if(emp.getMaritalStatus() == null){
            Error error = new Error("the field marital status is null");
            errors.add(error);
        }
        if(emp.getMobileNumber() == null){
            Error error = new Error("the field mobile number is null");
            errors.add(error);
        }
        if(emp.getPincode() == 0){
            Error error = new Error("the field pincode is null");
            errors.add(error);
        }
        if(emp.getProficiency() == null){
            Error error = new Error("the field proficiency is null");
            errors.add(error);
        }
        if(emp.getReference() == null){
            Error error = new Error("the field reference is null");
            errors.add(error);
        }
        if(emp.getSkill() == null){
            Error error = new Error("the field skill is null");
            errors.add(error);
        }
        if(emp.getState() == null){
            Error error = new Error("the field state is null");
            errors.add(error);
        }
        if(emp.getStayWith() == null){
            Error error = new Error("the field staywith is null");
            errors.add(error);
        }
        if(emp.getSummary() == null){
            Error error = new Error("the field summary is null");
            errors.add(error);
        }
        
        return errors;
    }
}
