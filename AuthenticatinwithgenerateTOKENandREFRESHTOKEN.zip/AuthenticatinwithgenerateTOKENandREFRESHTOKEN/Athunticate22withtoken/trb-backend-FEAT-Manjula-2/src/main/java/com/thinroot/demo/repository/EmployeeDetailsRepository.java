package com.thinroot.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.thinroot.demo.model.EmployeeDetails;
import com.thinroot.demo.model.EmployeeDetailsDTO;

@Repository
public interface EmployeeDetailsRepository extends JpaRepository<EmployeeDetails, String> {

	EmployeeDetails findByFirstName(String firstName);

	List<EmployeeDetails> findByFirstNameOrLastNameOrMailIdOrMobileNumberOrSkill(String firstName, String lastName,String mailId,String mobileNumber,String skill);


	//List<EmployeeDetails> findByEmpId(String empId);

	EmployeeDetailsDTO save(EmployeeDetailsDTO newEmp);
	EmployeeDetails findByMobileNumber(String mobileNumber);

	
}
