package com.thinroot.demo.service;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinroot.demo.model.EmployeeProject;
import com.thinroot.demo.repository.EmployeeProjectRepository;
import com.thinroot.demo.validator.BadRequestException;
import com.thinroot.demo.validator.ProjectValidator;

@Service
public class EmployeeProjectService {

	@Autowired
	private ProjectValidator projectValidator;
	@Autowired
	private EmployeeProjectRepository projectRepo;
	public EmployeeProject create(EmployeeProject projectDetails) {
		List<Error> errors =projectValidator.validateCreateProjectRequest(projectDetails);
		  
		   //if not success
		   if(errors.size() > 0) { 
			   throw new BadRequestException("you have missed the some values ",errors); 
		   }
		   else {
		return projectRepo.save(projectDetails);
	}
	}
	
	public Optional<EmployeeProject> findById(int projectid) {
		return projectRepo.findById(projectid);		
	}
	
	
	// multiple projects
	public List<EmployeeProject> findByempIdAll(String empId) {
		return projectRepo.findByEmpId1(empId);
		
	}
	 //to update the project details 
	
	public EmployeeProject update(EmployeeProject project,String empId,int projectid) {
			EmployeeProject pro=projectRepo.findByEmpIdOrProjectid(empId,projectid);
			pro.setProjectDetails(project.getProjectDetails());
			pro.setCompanyName(project.getCompanyName());
			pro.setExperienceMonths(project.getExperienceMonths());
			pro.setExperienceYears(project.getExperienceYears());
			pro.setProjectExperienceMonths(project.getProjectExperienceMonths());
			pro.setProjectExperienceYears(project.getProjectExperienceYears());
			pro.setJobTitle(project.getJobTitle());
			pro.setStartDateMonth(project.getStartDateMonth());
			pro.setStartDateYear(project.getStartDateYear());
			return projectRepo.save(pro);
		}
		
	
	//delete project by project id
	public void proDeleteById(int projectid) {
		
		projectRepo.deleteById(projectid);
	}
	
	
	public void deleteByempId(String empId) {
		// TODO Auto-generated method stub
		projectRepo.deleteByempId(empId);
	}
	
	
	public void deleteAllProject()	{
		
		projectRepo.deleteAll();
	}

}

