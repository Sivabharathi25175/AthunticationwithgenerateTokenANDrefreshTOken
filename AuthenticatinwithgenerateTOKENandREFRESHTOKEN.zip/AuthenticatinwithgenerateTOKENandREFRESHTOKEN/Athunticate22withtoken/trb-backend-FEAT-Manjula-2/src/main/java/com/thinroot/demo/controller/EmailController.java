package com.thinroot.demo.controller;

import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.thinroot.demo.model.DAOUser;
import com.thinroot.demo.service.EmailService;
import com.thinroot.demo.service.UserlistService;
@Controller
@RestController
public class EmailController {

	@Autowired
	private UserlistService listService;
	
	@Autowired
	private EmailService mailService;
	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	
	
	// forgot password 
	@PostMapping(value = "/forgotPassword")
	public ResponseEntity<?> ForgotPassword( @RequestParam("email") String userEmail, HttpServletRequest request) {	
		Optional<DAOUser> optional=listService.findUserByEmail(userEmail);
		System.out.println(optional);
		if(!optional.isPresent())
		{
			return new ResponseEntity<>("we didn't find the account for that mail",HttpStatus.NOT_FOUND);
			
		}
		else
		{
			DAOUser user=optional.get();
			user.setResetToken(UUID.randomUUID().toString());
			listService.saveUser(user);
		
		String appUrl = request.getScheme() + "://" + request.getServerName();
		SimpleMailMessage passwordResetMail=new SimpleMailMessage();
		passwordResetMail.setFrom("test@goally.in");
		passwordResetMail.setTo(user.getEmail());
		passwordResetMail.setSubject("Password reset request");
		passwordResetMail.setText("to set password click on the below link:\n "+appUrl+ "/reset?token="+user.getResetToken());
		mailService.sendEmail(passwordResetMail);
		
		return new ResponseEntity<>("A password reset link hass been sent to "+userEmail,HttpStatus.OK);
		//return ResponseEntity.status(HttpStatus.FOUND).location(URI.create("/reset?token="+user.getResetToken())).build();
		}	
    }
	@PostMapping("/reset")
	public ResponseEntity<?> setNewPassword( @RequestParam( "resetToken") String resetToken, @RequestParam( "password") String password ) {
		Optional<DAOUser> user = listService.findUserByResetToken(resetToken);
		if(user.isPresent())
		{
			DAOUser resetUser=user.get();
			resetUser.setPassword(encoder.encode(password));
			resetUser.setResetToken(null);
			listService.saveUser(resetUser);
			return new ResponseEntity<>(" You have successfully reset your password.  You may now login.",HttpStatus.ACCEPTED);
			}
		else {
			return new ResponseEntity<>("errorMessage Oops!  This is an invalid password reset link.",HttpStatus.NOT_FOUND);
			}
		//return "redirect:authenticate";
		}
	}
