package com.thinroot.demo.validator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.thinroot.demo.model.EmployeeProject;

@Component
public class ProjectValidator {

public List<Error> validateCreateProjectRequest(EmployeeProject project) {

		
        List<Error> errors = new ArrayList<>();

        // id
        if(project.getEmpId() == null || project.getEmpId()=="") {
            Error error = new Error("Employee id Should not be null");
            errors.add(error);
        }
        if(project.getCompanyName() == null || project.getCompanyName()=="") {
            Error error = new Error("provide company name");
            errors.add(error);
        }
        if(project.getProjectDetails()== null || project.getProjectDetails()=="") {
            Error error = new Error("provide project details");
            errors.add(error);
        }
		/*
		 * if(project.getExperienceMonths() == 0){ Error error = new
		 * Error("experince in months should not be null"); errors.add(error); }
		 */
        if(project.getExperienceYears() == 0){
            Error error = new Error("experiecnce in years  Should not be null");
            errors.add(error);
        }
        if(project.getJobTitle() == null || project.getJobTitle()==""){
            Error error = new Error("job title Should not be null");
            errors.add(error);
        }
        if(project.getProjectDetails() == null || project.getProjectDetails()==""){
            Error error = new Error("project details Should not be null");
            errors.add(error);
        }
		/*
		 * if(project.getProjectExperienceMonths() == 0){ Error error = new
		 * Error("project experirnce(in months) Should not be null"); errors.add(error);
		 * }
		 */
        if(project.getProjectExperienceYears() == 0){
            Error error = new Error("project experince(in years) Should not be null");
            errors.add(error);
        }
        if(project.getStartDateMonth() == 0){
            Error error = new Error(" please mention startdate");
            errors.add(error);
        }
        if(project.getStartDateYear() == 0){
            Error error = new Error("please mention startdate");
            errors.add(error);
        }
		return errors;
}
}
