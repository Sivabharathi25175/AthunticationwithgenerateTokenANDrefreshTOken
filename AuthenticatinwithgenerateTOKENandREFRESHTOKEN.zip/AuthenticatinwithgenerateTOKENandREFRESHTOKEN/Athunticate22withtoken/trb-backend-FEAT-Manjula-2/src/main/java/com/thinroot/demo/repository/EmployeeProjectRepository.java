package com.thinroot.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.thinroot.demo.model.EmployeeProject;

@Repository
public interface EmployeeProjectRepository extends JpaRepository<EmployeeProject,Integer>{

	
	EmployeeProject findByEmpId(String empId);


	// void deleteById(String empId);
	@Modifying 
	@Query(value = "DELETE FROM EmployeeProject e WHERE e.empId = :empId") 
	void deleteByempId(@Param(value="empId")String empId);

	
	@Query("SELECT p from EmployeeProject p "+"WHERE lower(p.empId) LIKE lower(concat('%', :empId, '%')) " )
	List<EmployeeProject> findByEmpId1(@Param(value = "empId") String empId);


	EmployeeProject findByEmpIdOrProjectid(String empId, int projectid);
}
