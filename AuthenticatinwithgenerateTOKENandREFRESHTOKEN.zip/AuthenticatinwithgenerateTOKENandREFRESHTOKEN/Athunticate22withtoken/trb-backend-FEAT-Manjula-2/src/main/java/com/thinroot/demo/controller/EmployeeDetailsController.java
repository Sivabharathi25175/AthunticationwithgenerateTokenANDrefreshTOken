package com.thinroot.demo.controller;


import java.util.List;
import java.util.Optional;


import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.thinroot.demo.model.EmployeeDetails;
import com.thinroot.demo.model.EmployeeDetailsDTO;
import com.thinroot.demo.model.EmployeePage;
import com.thinroot.demo.model.EmployeeSearchCriteria;
import com.thinroot.demo.repository.EmployeeDetailsRepository;
import com.thinroot.demo.service.EmployeeDetailsService;
import com.thinroot.demo.validator.BadRequestException;

@RestController
public class EmployeeDetailsController {

	@Value("${upoadDir}")
	private String uploadFolder;
	
	private ModelMapper modelMapper;
	
	
	public EmployeeDetailsController(ModelMapper modelMapper) {
		super();
		this.modelMapper = modelMapper;
	}


	@Autowired
	private EmployeeDetailsService employeeService;
	@Autowired
	private EmployeeDetailsRepository EmployeeDetailsRepo;

	//private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	//to save employee personal details	
	
	@PostMapping("/AddDetails")
	public @ResponseBody ResponseEntity<?> createEmployee(@RequestBody EmployeeDetails employeeDetails) {
		try {
			Optional<EmployeeDetails> details=EmployeeDetailsRepo.findById(employeeDetails.getEmpId());
			if(!details.isPresent())
			{
			employeeService.create(employeeDetails);
			return new ResponseEntity<>("successfully created",HttpStatus.OK);
			}
			else {
				return new ResponseEntity<>("employee already exists",HttpStatus.CONFLICT);
			}
		}
		catch(BadRequestException e) {
			 return new ResponseEntity<>("you are trying to add null value",HttpStatus.BAD_REQUEST);
		}
		catch(DataIntegrityViolationException e) {
			//throw new DataIntegrityViolationException("employee already exists",e);
			return new ResponseEntity<>("employee already exists with this mobile number or mail id ",HttpStatus.CONFLICT);
		}
	
	}
	//executed
	//to Get all employee details
	@GetMapping("/GetAllEmployee")
	public List<EmployeeDetails> listAllemp() {
		System.out.println("getting records");
		if(employeeService.listAll()==null)
		{
			throw new NullPointerException("no employee were found");
		}
		return employeeService.listAll();
	}
	
	//get single employee details
	@RequestMapping("/getEmployee")
	public EmployeeDetails getEmployee(@RequestParam String empId) {
		System.out.println("getting record!!!!");
		return employeeService.findByempid(empId)
				// mod
			.orElseThrow(()-> new UsernameNotFoundException("employee Does not exist wit the id   "+empId));
	}
	

	//delete single employee details
	@DeleteMapping("/deleteEmployee")
	public ResponseEntity<?> delete(@RequestParam String empId) {
		Optional<EmployeeDetails> details=employeeService.findByempid(empId);
		if(details.isPresent())
		{
		employeeService.deleteById(empId);
		return new ResponseEntity<>("deleted succesfully ",HttpStatus.OK);
		}
		else {
		return new ResponseEntity<>("employee not found ",HttpStatus.NOT_FOUND);
		}
	}

	//delete all
	@DeleteMapping("/deleteAllEmployee")
	public String deleteAll() {
		employeeService.delete();
		return "all records deleted successfully";
	}
	
	// to update the employee details
	@PutMapping("/updateEmployee")
	public @ResponseBody ResponseEntity<?> updateEmployee(@RequestBody EmployeeDetails employeeDetails, @RequestParam String empId ) {
			employeeService.update(empId, employeeDetails);
			return new ResponseEntity<>("updated successfully",HttpStatus.OK);			
			
		}

	@GetMapping("/sorting")
	public ResponseEntity<Page<EmployeeDetails>> getEmployees(EmployeePage employeePage,
                                                   EmployeeSearchCriteria employeeSearchCriteria) {
		return new ResponseEntity<>(employeeService.getEmployees(employeePage, employeeSearchCriteria), HttpStatus.OK);    
	}


	//for filtering by email,mobile number,name,name
	@GetMapping("/filters")
	public ResponseEntity<List<EmployeeDetails>> getEmployeeByFistOrLastNameOrAll(@RequestParam(required=false) String firstName,@RequestParam(required=false) String lastName,@RequestParam(required=false) String mailId,@RequestParam(required=false) String mobileNumber, @RequestParam(required=false) String skill) {
		return new ResponseEntity<List<EmployeeDetails>>(employeeService.findByFirstNameOrLastName(firstName, lastName,mailId,mobileNumber,skill), HttpStatus.OK);
	}


	// get single employee personal details with load level basic
	@GetMapping("/getEmployeePersonalDetails")
	public EmployeeDetailsDTO getEmp(@RequestParam String  empId)  {
		EmployeeDetails p = employeeService.findByempid(empId)
				.orElseThrow(() -> new UsernameNotFoundException("employee does not found "));
		EmployeeDetailsDTO dto = modelMapper.map(p, EmployeeDetailsDTO.class);
		return dto;
	}

	// to get all employee personal details with load level basic
	@GetMapping("/GetAllEmployeePersonalDetails")
	public List<EmployeeDetailsDTO> getAllEmpPer() {
		List<EmployeeDetails> emp=EmployeeDetailsRepo.findAll();
		List<EmployeeDetailsDTO> empDto=modelMapper.map(emp, new TypeToken<List<EmployeeDetailsDTO>>() {}.getType());
		return empDto;
		
	}

}

