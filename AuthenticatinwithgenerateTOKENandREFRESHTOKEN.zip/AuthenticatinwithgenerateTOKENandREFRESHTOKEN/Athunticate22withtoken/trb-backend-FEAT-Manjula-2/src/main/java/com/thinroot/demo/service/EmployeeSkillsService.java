package com.thinroot.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinroot.demo.repository.EmployeeSkillsRepository;
import com.thinroot.demo.model.EmployeeSkills;



@Service
public class EmployeeSkillsService {
@Autowired
private EmployeeSkillsRepository skillrepo;
	
	public List<EmployeeSkills> listAll()
	{
		return (List<EmployeeSkills>) skillrepo.findAll();
		
	}
	
	
}

