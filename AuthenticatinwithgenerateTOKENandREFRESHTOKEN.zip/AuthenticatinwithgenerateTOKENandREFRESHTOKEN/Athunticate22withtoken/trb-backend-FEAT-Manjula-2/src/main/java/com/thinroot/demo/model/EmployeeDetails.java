package com.thinroot.demo.model;

import javax.persistence.Entity;

import javax.persistence.Table;



import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Table(name="EmployeeDetails")
@Entity
//@JsonIdentityInfo(
//		   generator = ObjectIdGenerators.PropertyGenerator.class,
//		   property = "empId")
public class EmployeeDetails {
		@Id
		@Column(name="emp_id",unique=true,nullable=false)
		//@GeneratedValue
		//@GeneratedValue(generator="system-uuid")
		//@GenericGenerator(name="system-uuid", strategy = "uuid")
	
		private String empId;
		@Column(name="first_name",nullable=false)
		private String firstName;
		private String middleName;
		private String lastName;
		private String homeAddress;
		/*
		 * @Column(length=1000) 
		 private byte[] photo;
		 */
		private String mobileNumber;
		private String mailId;
		private String gender;
		private String maritalStatus;
		private int age;
		private String area;
		private String country;
		private String state;
		private String city;
		private int pincode;
		private String currentAddress;
		private String stayWith;
		private String summary;
		/* private byte[] resume; */
		private String reference;
		private String language;
		private String expectedSalary;
		private String currentSalary;
		private String skill;
		private String proficiency;
	
		public EmployeeDetails() {
			super();
		}
		public EmployeeDetails(String empId, String firstName, String middleName, String lastName, String homeAddress,
				 String mobileNumber, String mailId, String gender, String maritalStatus, int age,
				String area, String country, String state, String city, int pincode, String currentAddress,
				String stayWith, String summary,  String reference, String language, String expectedSalary,
				String currentSalary, String skill, String proficiency) {
			super();
			this.empId = empId;
			this.firstName = firstName;
			this.middleName = middleName;
			this.lastName = lastName;
			this.homeAddress = homeAddress;
			this.mobileNumber = mobileNumber;
			this.mailId = mailId;
			this.gender = gender;
			this.maritalStatus = maritalStatus;
			this.age = age;
			this.area = area;
			this.country = country;
			this.state = state;
			this.city = city;
			this.pincode = pincode;
			this.currentAddress = currentAddress;
			this.stayWith = stayWith;
			this.summary = summary;
			this.reference = reference;
			this.language = language;
			this.expectedSalary = expectedSalary;
			this.currentSalary = currentSalary;
			this.skill = skill;
			this.proficiency = proficiency;
		}
		public String getEmpId() {
			return empId;
		}
		public void setEmpId(String empId) {
			this.empId = empId;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getMiddleName() {
			return middleName;
		}
		public void setMiddleName(String middleName) {
			this.middleName = middleName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getHomeAddress() {
			return homeAddress;
		}
		public void setHomeAddress(String homeAddress) {
			this.homeAddress = homeAddress;
		}

		/*
		 * public byte[] getPhoto() { return photo; } public void setPhoto(byte[] photo)
		 * { this.photo = photo; }
		 */
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public String getMailId() {
			return mailId;
		}
		public void setMailId(String mailId) {
			this.mailId = mailId;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getMaritalStatus() {
			return maritalStatus;
		}
		public void setMaritalStatus(String maritalStatus) {
			this.maritalStatus = maritalStatus;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public String getArea() {
			return area;
		}
		public void setArea(String area) {
			this.area = area;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public int getPincode() {
			return pincode;
		}
		public void setPincode(int pincode) {
			this.pincode = pincode;
		}
		public String getCurrentAddress() {
			return currentAddress;
		}
		public void setCurrentAddress(String currentAddress) {
			this.currentAddress = currentAddress;
		}
		public String getStayWith() {
			return stayWith;
		}
		public void setStayWith(String stayWith) {
			this.stayWith = stayWith;
		}
		public String getSummary() {
			return summary;
		}
		public void setSummary(String summary) {
			this.summary = summary;
		}

		/*
		 * public byte[] getResume() { return resume; } public void setResume(byte[]
		 * resume) { this.resume = resume; }
		 */
		public String getReference() {
			return reference;
		}
		public void setReference(String reference) {
			this.reference = reference;
		}
		public String getLanguage() {
			return language;
		}
		public void setLanguage(String language) {
			this.language = language;
		}
		public String getExpectedSalary() {
			return expectedSalary;
		}
		public void setExpectedSalary(String expectedSalary) {
			this.expectedSalary = expectedSalary;
		}
		public String getCurrentSalary() {
			return currentSalary;
		}
		public void setCurrentSalary(String currentSalary) {
			this.currentSalary = currentSalary;
		}
		public String getSkill() {
			return skill;
		}
		public void setSkill(String skill) {
			this.skill = skill;
		}
		public String getProficiency() {
			return proficiency;
		}
		public void setProficiency(String proficiency) {
			this.proficiency = proficiency;
		}
		
		@OneToMany(mappedBy = "EmployeeDetails", cascade=CascadeType.ALL, orphanRemoval = true)
	    private Set<EmployeeProject> EmployeeProject = new HashSet<EmployeeProject>();
		
		@OneToMany(mappedBy = "EmployeeDetails", cascade=CascadeType.ALL, orphanRemoval = true)
	    private Set<EducationalDetails> EducationalDetails = new HashSet<EducationalDetails>();

		public Set<EmployeeProject> getEmployeeProject() {
			return EmployeeProject;
		}
		public void setEmployeeProject(Set<EmployeeProject> employeeProject) {
			EmployeeProject = employeeProject;
		}
		public Set<EducationalDetails> getEducationalDetails() {
			return EducationalDetails;
		}
		public void setEducationalDetails(Set<EducationalDetails> educationalDetails) {
			EducationalDetails = educationalDetails;
		}
		@Override
		public String toString() {
			return "EmplyeeDetails [empId=" + empId + ", firstName=" + firstName + ", middleName=" + middleName
					+ ", lastName=" + lastName + ", homeAddress=" + homeAddress + ", mobileNumber="
					+ mobileNumber + ", mailId=" + mailId + ", gender=" + gender + ", maritalStatus=" + maritalStatus
					+ ", age=" + age + ", area=" + area + ", country=" + country + ", state=" + state + ", city=" + city
					+ ", pincode=" + pincode + ", currentAddress=" + currentAddress + ", stayWith=" + stayWith
					+ ", summary=" + summary + ", reference=" + reference + ", language="
					+ language + ", expectedSalary=" + expectedSalary + ", currentSalary=" + currentSalary + ", skill="
					+ skill + ", proficiency=" + proficiency + "]";
		}
}
