package com.thinroot.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity
public class EmployeeSkills {
	@Id
	private int skillId;
	private String skill;
	
	public EmployeeSkills() {
		super();
	}
	public EmployeeSkills(int skillId, String skill) {
		super();
		this.skillId = skillId;
		this.skill = skill;
	}
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	@Override
	public String toString() {
		return "EmployeeSkills [skillId=" + skillId + ", skill=" + skill + "]";
	}
	
	

}
