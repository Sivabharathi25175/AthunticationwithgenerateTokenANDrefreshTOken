package com.thinroot.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.thinroot.demo.model.EducationalDetails;

@Repository
public interface EducationalDetailsRepository extends JpaRepository<EducationalDetails, Integer>{

	@Query("SELECT e from EducationalDetails e "+"WHERE lower(e.empId) LIKE lower(concat('%', :empId, '%')) " )
	List<EducationalDetails> findByEmpId(@Param(value="empId")String empId);

	@Modifying 
	@Query(value = "DELETE FROM EducationalDetails e WHERE e.empId = :empId") 
	void deleteByempId(@Param(value="empId")String empId);

	EducationalDetails findByEmpIdOrEdid(String empId, int edid);

}
