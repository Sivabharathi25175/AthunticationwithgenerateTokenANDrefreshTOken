package com.thinroot.demo.model;



import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//import lombok.AllArgsConstructor;
//import lombok.NoArgsConstructor;

@Entity
@Table
//@AllArgsConstructor
//@NoArgsConstructor
public class EducationalDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int edid;
	private String qualification;
	private String stream;
	private int startYear;
	private int endYear;
	private String percentage;
	private String arrears;
	@Column(name="emp_id")
	private String empId;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(foreignKey = @javax.persistence.ForeignKey(name = "fk1_emp_id"), name="emp_id", referencedColumnName = "emp_id", columnDefinition = "String",insertable=false,updatable=false)
    private EmployeeDetails EmployeeDetails;
	
	
	
	public EducationalDetails() {
		super();
	}



	public EducationalDetails(int edid, String qualification, String stream, int startYear, int endYear,
			String percentage, String arrears, String empId) {
		super();
		this.edid = edid;
		this.qualification = qualification;
		this.stream = stream;
		this.startYear = startYear;
		this.endYear = endYear;
		this.percentage = percentage;
		this.arrears = arrears;
		this.empId = empId;
		//EmployeeDetails = employeeDetails;
	}



	public int getEdid() {
		return edid;
	}



	public void setEdid(int edid) {
		this.edid = edid;
	}



	public String getQualification() {
		return qualification;
	}



	public void setQualification(String qualification) {
		this.qualification = qualification;
	}



	public String getStream() {
		return stream;
	}



	public void setStream(String stream) {
		this.stream = stream;
	}



	public int getStartYear() {
		return startYear;
	}



	public void setStartYear(int startYear) {
		this.startYear = startYear;
	}



	public int getEndYear() {
		return endYear;
	}



	public void setEndYear(int endYear) {
		this.endYear = endYear;
	}



	public String getPercentage() {
		return percentage;
	}



	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}



	public String getArrears() {
		return arrears;
	}



	public void setArrears(String arrears) {
		this.arrears = arrears;
	}



	public String getEmpId() {
		return empId;
	}



	public void setEmpId(String empId) {
		this.empId = empId;
	}



	


	@Override
	public String toString() {
		return "EducationalDetails [edid=" + edid + ", qualification=" + qualification + ", stream=" + stream
				+ ", startYear=" + startYear + ", endYear=" + endYear + ", percentage=" + percentage + ", arrears="
				+ arrears  + ", empid=" + empId + "]";
	}
	

}

