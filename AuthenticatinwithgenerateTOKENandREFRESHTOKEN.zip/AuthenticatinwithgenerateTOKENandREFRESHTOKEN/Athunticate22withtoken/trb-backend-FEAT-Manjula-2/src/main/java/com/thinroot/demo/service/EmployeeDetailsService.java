package com.thinroot.demo.service;

import java.util.List;
import java.util.Optional;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.thinroot.demo.model.EmployeeDetails;
import com.thinroot.demo.model.EmployeeDetailsDTO;
import com.thinroot.demo.model.EmployeePage;import com.thinroot.demo.model.EmployeeSearchCriteria;
import com.thinroot.demo.repository.EmployeeCriteriaRepository;
import com.thinroot.demo.repository.EmployeeDetailsRepository;
import com.thinroot.demo.validator.BadRequestException;
import com.thinroot.demo.validator.EmployeeValidator;

@Service
public class EmployeeDetailsService {
	@Autowired
	private EmployeeDetailsRepository employeeRepo;
	
	@Autowired
	private EmployeeValidator employeeValidator;
	private ModelMapper modelMapper;
    private final EmployeeCriteriaRepository employeeCriteriaRepository;

	
    // to create
	public EmployeeDetails create(EmployeeDetails empDetails)  {		
		  List<Error> errors =employeeValidator.validateCreateEmployeeRequest(empDetails);
		  
		   //if not success
		   if(errors.size() > 0) { 
			   throw new BadRequestException("you have missed the some values ",errors); 
		   }
		return employeeRepo.save(empDetails);
	}

    // to listALL employee
	public List<EmployeeDetails> listAll() {
		return (List<EmployeeDetails>) employeeRepo.findAll();
		
	}
	//delete
	public void delete() {
		employeeRepo.deleteAll();
	}
	//delete by id
	public void deleteById(String empId) {
		employeeRepo.deleteById(empId);
	}
	
	//getA single employee details
	public Optional<EmployeeDetails> findByempid(String empId) {
		
		return employeeRepo.findById(empId);
	}
	
	// update Employee
	public EmployeeDetails update(String empId, EmployeeDetails employeeDetails) {
		EmployeeDetails employee=employeeRepo.findById(empId)
				.orElseThrow(()-> new UsernameNotFoundException("employee Does not exist wit the id   "+empId));
		employee.setEmpId(empId);
		employee.setFirstName(employeeDetails.getFirstName());
		employee.setMiddleName(employeeDetails.getMiddleName());
		employee.setLastName(employeeDetails.getLastName());
		employee.setHomeAddress(employeeDetails.getHomeAddress());
		employee.setMobileNumber(employeeDetails.getMobileNumber());
		employee.setMailId(employeeDetails.getMailId());
		employee.setGender(employeeDetails.getGender());
		employee.setMaritalStatus(employeeDetails.getMaritalStatus());
		employee.setAge(employeeDetails.getAge());
		employee.setArea(employeeDetails.getArea());
		employee.setCountry(employeeDetails.getCountry());
		employee.setState(employeeDetails.getState());
		employee.setCity(employeeDetails.getCity());
		employee.setPincode(employeeDetails.getPincode());;
		employee.setCurrentAddress(employeeDetails.getCurrentAddress());
		employee.setStayWith(employeeDetails.getStayWith());
		employee.setSummary(employeeDetails.getSummary());
		employee.setReference(employeeDetails.getReference());
		employee.setLanguage(employeeDetails.getLanguage());
		employee.setExpectedSalary(employeeDetails.getExpectedSalary());
		employee.setCurrentSalary(employeeDetails.getCurrentSalary());
		employee.setSkill(employeeDetails.getSkill());
		employee.setProficiency(employeeDetails.getProficiency());	
		return employeeRepo.save(employee);
	}
	
	
    // mod

    public EmployeeDetailsService(EmployeeDetailsRepository employeeRepository,
                           EmployeeCriteriaRepository employeeCriteriaRepository,ModelMapper modelMapper) {
        this.employeeRepo = employeeRepository;
        this.employeeCriteriaRepository = employeeCriteriaRepository;
        this.modelMapper = modelMapper;
        
    }

    //for pagination
    public Page<EmployeeDetails> getEmployees(EmployeePage employeePage,
                                       EmployeeSearchCriteria employeeSearchCriteria) {
        return employeeCriteriaRepository.findAllWithFilters(employeePage, employeeSearchCriteria);
    }
  
    //to get personal details
    public EmployeeDetailsDTO saveDTO(EmployeeDetails details) {
    	EmployeeDetailsDTO newEmp=modelMapper.map(details, EmployeeDetailsDTO.class);
      			return employeeRepo.save(newEmp);
    }
    
    // find by first name
	public EmployeeDetails findByfirstName(String firstName) {
		// TODO Auto-generated method stub
		return employeeRepo.findByFirstName(firstName);
	}


    // find by first name,last name,mail id,mobile number,skill
	public List<EmployeeDetails> findByFirstNameOrLastName(String firstName, String lastName,
			String mailId,String mobileNumber,String skill) {
		return employeeRepo.findByFirstNameOrLastNameOrMailIdOrMobileNumberOrSkill(firstName, lastName,mailId,mobileNumber,skill);
	}
    
	
	
	
	
}
