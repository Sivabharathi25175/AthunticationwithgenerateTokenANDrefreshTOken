package com.thinroot.demo.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinroot.demo.model.EducationalDetails;
import com.thinroot.demo.repository.EducationalDetailsRepository;
import com.thinroot.demo.validator.BadRequestException;
import com.thinroot.demo.validator.EducationValidator;

@Service
public class EducationalDetailsService {

	@Autowired
	private EducationalDetailsRepository educationrepo;
	@Autowired
	private EducationValidator educationValidator;
	
	public EducationalDetails create(EducationalDetails educationDetails) {
		List<Error> errors =educationValidator.validateCreateEducationRequest(educationDetails);
		  
		   //if not success
		   if(errors.size() > 0) { 
			   throw new BadRequestException("you have missed the some values ",errors); 
		   }
		return educationrepo.save(educationDetails);
	}
	
	
	public List<EducationalDetails> findByempId(String empId) {
		
			return educationrepo.findByEmpId(empId);
		}
	public EducationalDetails update(EducationalDetails educationalDetails, String empId ,int edid) {
		EducationalDetails edu=educationrepo.findByEmpIdOrEdid(empId,edid);
		edu.setEdid(educationalDetails.getEdid());
		edu.setEmpId(educationalDetails.getEmpId());
		edu.setArrears(educationalDetails.getArrears());
	    edu.setEndYear(educationalDetails.getEndYear());
	    edu.setStartYear(educationalDetails.getStartYear());
	    edu.setQualification(educationalDetails.getQualification());
	    edu.setPercentage(educationalDetails.getPercentage());
	    edu.setStream(educationalDetails.getStream());
	    return educationrepo.save(edu);	
	}
	//delete all
	public void delete() {
		 educationrepo.deleteAll();
	}
	//delete by  educational id
	public void deleteById(int edid)  {
		educationrepo.deleteById(edid);
	}

	// delete education by employee id
	public void deleteByempId(String empId) {
		// TODO Auto-generated method stub
		educationrepo.deleteByempId(empId);
	}	
}
