package com.thinroot.demo.validator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.thinroot.demo.model.EducationalDetails;

@Component
public class EducationValidator {
	
public List<Error> validateCreateEducationRequest(EducationalDetails education) {

		
        List<Error> errors = new ArrayList<>();

        // id
        if(education.getEmpId() == null || education.getEmpId()==""){
            Error error = new Error("Employee Should not be null");
            errors.add(error);
        }
        if(education.getEndYear() == 0 ){
            Error error = new Error("please mention endyear");
            errors.add(error);
        }
        if(education.getPercentage() == null || education.getPercentage()==""){
            Error error = new Error("please mention the percentage");
            errors.add(error);
        }
        if(education.getQualification() == null || education.getQualification()==""){
            Error error = new Error("Employee qualification not be null");
            errors.add(error);
        }
        if(education.getStartYear() == 0 ){
            Error error = new Error("start year not be null");
            errors.add(error);
        }
        if(education.getStream() == null || education.getStream()==""){
            Error error = new Error("please mention the stream");
            errors.add(error);
        }
		return errors;
       }


}
