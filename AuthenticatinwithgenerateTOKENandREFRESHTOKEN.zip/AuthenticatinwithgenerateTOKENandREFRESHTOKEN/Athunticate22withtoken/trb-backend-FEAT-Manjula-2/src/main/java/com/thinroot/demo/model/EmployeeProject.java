package com.thinroot.demo.model;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//import lombok.AllArgsConstructor;
//import lombok.NoArgsConstructor;

@Table
@Entity
//@AllArgsConstructor
//@NoArgsConstructor
//@NamedQuery(name = "emp_id", query = "select emp_id from EmployeeProject")
public class EmployeeProject {
	@Column(name="emp_id")
	private String empId;
	private String projectDetails;
	private int experienceYears;
	private int experienceMonths;
	private String companyName;
	private String jobTitle;
	private int startDateYear;
	private int startDateMonth;
	private int projectExperienceYears;
	private int projectExperienceMonths;
	@Id
	@Column(name="project_id",nullable=false)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int projectid;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(foreignKey = @javax.persistence.ForeignKey(name = "fk_emp_id"), name="emp_id", referencedColumnName = "emp_id", columnDefinition = "String",insertable=false,updatable=false)
    private EmployeeDetails EmployeeDetails;
	
	public EmployeeProject() {
		super();
	}


	public EmployeeProject(String empId, String projectDetails, int experienceYears, int experienceMonths,
			String companyName, String jobTitle, int startDateYear, int startDateMonth, int projectExperienceYears,
			int projectExperienceMonths, int projectid) {
		super();
		this.empId = empId;
		this.projectDetails = projectDetails;
		this.experienceYears = experienceYears;
		this.experienceMonths = experienceMonths;
		this.companyName = companyName;
		this.jobTitle = jobTitle;
		this.startDateYear = startDateYear;
		this.startDateMonth = startDateMonth;
		this.projectExperienceYears = projectExperienceYears;
		this.projectExperienceMonths = projectExperienceMonths;
		this.projectid = projectid;
	}


	public String getEmpId() {
		return empId;
	}


	public void setEmpId(String empId) {
		this.empId = empId;
	}


	public String getProjectDetails() {
		return projectDetails;
	}


	public void setProjectDetails(String projectDetails) {
		this.projectDetails = projectDetails;
	}


	public int getExperienceYears() {
		return experienceYears;
	}


	public void setExperienceYears(int experienceYears) {
		this.experienceYears = experienceYears;
	}


	public int getExperienceMonths() {
		return experienceMonths;
	}


	public void setExperienceMonths(int experienceMonths) {
		this.experienceMonths = experienceMonths;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public String getJobTitle() {
		return jobTitle;
	}


	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}


	public int getStartDateYear() {
		return startDateYear;
	}


	public void setStartDateYear(int startDateYear) {
		this.startDateYear = startDateYear;
	}


	public int getStartDateMonth() {
		return startDateMonth;
	}


	public void setStartDateMonth(int startDateMonth) {
		this.startDateMonth = startDateMonth;
	}


	public int getProjectExperienceYears() {
		return projectExperienceYears;
	}


	public void setProjectExperienceYears(int projectExperienceYears) {
		this.projectExperienceYears = projectExperienceYears;
	}


	public int getProjectExperienceMonths() {
		return projectExperienceMonths;
	}


	public void setProjectExperienceMonths(int projectExperienceMonths) {
		this.projectExperienceMonths = projectExperienceMonths;
	}


	public int getProjectid() {
		return projectid;
	}


	public void setProjectid(int projectid) {
		this.projectid = projectid;
	}


	@Override
	public String toString() {
		return "EmployeeProject [empId=" + empId + ", projectDetails=" + projectDetails + ", experienceYears="
				+ experienceYears + ", experienceMonths=" + experienceMonths + ", companyName=" + companyName
				+ ", jobTitle=" + jobTitle + ", startDateYear=" + startDateYear + ", startDateMonth=" + startDateMonth
				+ ", projectExperienceYears=" + projectExperienceYears + ", projectExperienceMonths="
				+ projectExperienceMonths + ", projectid=" + projectid + "]";
	}

}

