package com.thinroot.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Repository;

import com.thinroot.demo.model.DAOUser;



@Repository
public interface UserRepository extends JpaRepository<DAOUser, Long> {
	
	DAOUser findByUsername(String username);

	User save(User user);

	void deleteByUsername(String username);

	void deleteByUsername(DAOUser user);
	
	Optional<DAOUser> findByEmail(String emial);
	Optional<DAOUser> findByResetToken(String resetToken);
	

}